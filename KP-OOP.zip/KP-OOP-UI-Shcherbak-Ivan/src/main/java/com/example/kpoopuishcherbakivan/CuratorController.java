package com.example.kpoopuishcherbakivan;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class CuratorController {

    @FXML private ComboBox<String> groupBox;
    @FXML private Button backBtn;
    @FXML private TableView<Workentry> workTable;
    @FXML private TableColumn<Workentry, String> colTeacher;
    @FXML private TableColumn<Workentry, String> colSubject;
    @FXML private TableColumn<Workentry, String> colDate;
    @FXML private TableColumn<Workentry, Double> colHours;
    @FXML private TableColumn<Workentry, String> colType;
    @FXML private Label infoLabel;

    private ObservableList<Workentry> allEntries;

    @FXML
    void initialize() {
        colTeacher.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getTeacher().getFullName()));
        colSubject.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getSubject().getName()));
        colDate.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getDate().toString()));
        colHours.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleDoubleProperty(
                        cell.getValue().getHours()).asObject());
        colType.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getType().getDisplayName()));

        allEntries = FXCollections.observableArrayList(DataStore.getEntries());

        // Збираємо групи
        ObservableList<String> groups = FXCollections.observableArrayList();
        for (Workentry e : allEntries) {
            String code = e.getGroup().getCode();
            if (!groups.contains(code)) groups.add(code);
        }
        groupBox.setItems(groups);
        groupBox.setValue(groups.get(0));
        filterByGroup(groups.get(0));
    }

    @FXML
    void onGroupChanged() {
        filterByGroup(groupBox.getValue());
    }

    private void filterByGroup(String code) {
        ObservableList<Workentry> filtered = FXCollections.observableArrayList();
        double total = 0;
        for (Workentry e : allEntries) {
            if (e.getGroup().getCode().equals(code)) {
                filtered.add(e);
                total += e.getHours();
            }
        }
        workTable.setItems(filtered);
        infoLabel.setText("Занять: " + filtered.size() + "  |  Годин: " + total);
    }

    @FXML
    void onBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login-view.fxml"));
            Stage stage = (Stage) backBtn.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 400, 300));
        } catch (Exception e) { e.printStackTrace(); }
    }
}