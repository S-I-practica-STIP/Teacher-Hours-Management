package com.example.kpoopuishcherbakivan;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FileManager {

    private static final String FILE_PATH = "workentries.txt";

    public static boolean save(List<Workentry> entries) {
        try (BufferedWriter writer =
                     new BufferedWriter(new FileWriter(FILE_PATH))) {

            for (Workentry e : entries) {
                String line = e.getId() + ";" +
                        e.getTeacher().getFirstName() + ";" +
                        e.getTeacher().getLastName() + ";" +
                        e.getTeacher().getDepartment() + ";" +
                        e.getSubject().getName() + ";" +
                        e.getGroup().getCode() + ";" +
                        e.getDate().toString() + ";" +
                        e.getHours() + ";" +
                        e.getType().toString() + ";" +
                        (e.getDescription() != null ? e.getDescription() : "");
                writer.write(line);
                writer.newLine();
            }
            return true;

        } catch (IOException e) {
            System.err.println("Помилка збереження: " + e.getMessage());
            return false;
        }
    }

    public static List<Workentry> load() {
        List<Workentry> result = new ArrayList<>();
        File file = new File(FILE_PATH);

        if (!file.exists()) {
            System.out.println("Файл не знайдено: " + FILE_PATH);
            return result;
        }

        try (BufferedReader reader =
                     new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            long idCounter = 1;

            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue; // Пропускаємо порожні рядки

                String[] parts = line.split(";", -1);
                if (parts.length < 9) continue; // Некоректний рядок

                try {

                    Teacher teacher = new Teacher(
                            idCounter,
                            parts[1],
                            parts[2],
                            parts[3]
                    );

                    Subject subject = new Subject(idCounter, parts[4]);

                    Studentgroup group = new Studentgroup(idCounter, parts[5]);

                    LocalDate date = LocalDate.parse(parts[6]);
                    double hours = Double.parseDouble(parts[7]);
                    Worktype type = Worktype.valueOf(parts[8]);
                    String desc = parts.length > 9 ? parts[9] : "";

                    result.add(new Workentry(
                            idCounter++, teacher, subject,
                            group, date, hours, type, desc));

                } catch (Exception ex) {
                    System.err.println("Помилка рядка: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Помилка завантаження: " + e.getMessage());
        }
        return result;
    }

    public static String getFilePath() { return FILE_PATH; }
}
