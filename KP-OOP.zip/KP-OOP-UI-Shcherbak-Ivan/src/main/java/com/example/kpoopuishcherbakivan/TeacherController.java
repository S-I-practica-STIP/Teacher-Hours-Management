package com.example.kpoopuishcherbakivan;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class TeacherController {

    @FXML private ComboBox<String> teacherBox;
    @FXML private Button backBtn;
    @FXML private TableView<Workentry> workTable;
    @FXML private TableColumn<Workentry, String> colSubject;
    @FXML private TableColumn<Workentry, String> colGroup;
    @FXML private TableColumn<Workentry, String> colDate;
    @FXML private TableColumn<Workentry, Double> colHours;
    @FXML private TableColumn<Workentry, String> colType;
    @FXML private Label totalLabel;

    private ObservableList<Workentry> allEntries;

    @FXML
    void initialize() {
        colSubject.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getSubject().getName()));
        colGroup.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getGroup().getCode()));
        colDate.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getDate().toString()));
        colHours.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleDoubleProperty(
                        cell.getValue().getHours()).asObject());
        colType.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getType().getDisplayName()));

        allEntries = FXCollections.observableArrayList(DataStore.getEntries());

        // Збираємо імена викладачів
        ObservableList<String> names = FXCollections.observableArrayList();
        for (Workentry e : allEntries) {
            String name = e.getTeacher().getFullName();
            if (!names.contains(name)) names.add(name);
        }
        teacherBox.setItems(names);
        teacherBox.setValue(names.get(0));
        filterByTeacher(names.get(0));
    }

    @FXML
    void onTeacherChanged() {
        filterByTeacher(teacherBox.getValue());
    }

    private void filterByTeacher(String name) {
        ObservableList<Workentry> filtered = FXCollections.observableArrayList();
        double total = 0;
        for (Workentry e : allEntries) {
            if (e.getTeacher().getFullName().equals(name)) {
                filtered.add(e);
                total += e.getHours();
            }
        }
        workTable.setItems(filtered);
        totalLabel.setText("Всього годин: " + total);
    }

    @FXML
    void onBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login-view.fxml"));
            Stage stage = (Stage) backBtn.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 400, 300));
        } catch (Exception e) { e.printStackTrace(); }
    }
}