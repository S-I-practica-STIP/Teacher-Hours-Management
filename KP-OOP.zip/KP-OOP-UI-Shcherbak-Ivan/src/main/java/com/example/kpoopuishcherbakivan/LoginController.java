package com.example.kpoopuishcherbakivan;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.stage.Stage;

public class LoginController {

    @FXML private ComboBox<String> roleBox;
    @FXML private Button loginBtn;

    @FXML
    void initialize() {
        roleBox.setItems(FXCollections.observableArrayList(
                "Викладач",
                "Куратор",
                "Загальна статистика",
                "Адмін (всі записи)"
        ));
        roleBox.setValue("Викладач");
    }

    @FXML
    void onLogin() {
        String role = roleBox.getValue();
        String fxml;

        if (role.equals("Викладач"))                    fxml = "teacher-view.fxml";
        else if (role.equals("Куратор"))                fxml = "curator-view.fxml";
        else if (role.equals("Загальна статистика"))    fxml = "stats-view.fxml";
        else                                            fxml = "main-view.fxml";


        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource(fxml));
            Stage stage = (Stage) loginBtn.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 800, 600));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}