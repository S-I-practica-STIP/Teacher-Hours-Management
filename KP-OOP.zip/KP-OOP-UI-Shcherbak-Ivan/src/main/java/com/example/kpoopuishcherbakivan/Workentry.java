package com.example.kpoopuishcherbakivan;

import java.time.LocalDate;

public class Workentry {

    private Long id;
    private Teacher teacher;
    private Subject subject;
    private Studentgroup group;
    private LocalDate date;
    private double hours;
    private Worktype type;
    private String description;

    public Workentry(Long id, Teacher teacher, Subject subject,
                     Studentgroup group, LocalDate date,
                     double hours, Worktype type, String description) {
        this.id = id;
        this.teacher = teacher;
        this.subject = subject;
        this.group = group;
        this.date = date;
        this.hours = hours;
        this.type = type;
        this.description = description;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Teacher getTeacher() { return teacher; }
    public void setTeacher(Teacher teacher) { this.teacher = teacher; }

    public Subject getSubject() { return subject; }
    public void setSubject(Subject subject) { this.subject = subject; }

    public Studentgroup getGroup() { return group; }
    public void setGroup(Studentgroup group) { this.group = group; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public double getHours() { return hours; }
    public void setHours(double hours) { this.hours = hours; }

    public Worktype getType() { return type; }
    public void setType(Worktype type) { this.type = type; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    @Override
    public String toString() {
        return "WorkEntry{id=" + id +
                ", teacher=" + teacher.getFullName() +
                ", subject=" + subject.getName() +
                ", group=" + group.getCode() +
                ", date=" + date +
                ", hours=" + hours +
                ", type=" + type +
                "}";
    }
}