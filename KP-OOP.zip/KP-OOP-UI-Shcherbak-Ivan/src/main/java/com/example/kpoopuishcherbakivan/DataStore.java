package com.example.kpoopuishcherbakivan;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Клас-сховище тестових даних системи.
 * Дані взяті з реального розкладу коледжу 2024-2025 навчального року.
 */
public class DataStore {

    public static List<Workentry> getEntries() {

        // ── Викладачі ──
        Teacher goliver  = new Teacher(1L,  "Надія",     "Голівер",      "Кафедра іноземних мов");
        Teacher tsymbal  = new Teacher(2L,  "Тетяна",    "Цимбал",       "Кафедра філософії");
        Teacher brovko   = new Teacher(3L,  "Дмитро",    "Бровко",       "Кафедра наукових досліджень");
        Teacher tron     = new Teacher(4L,  "Віталій",   "Тронь",        "Кафедра наукових досліджень");
        Teacher afanasev = new Teacher(5L,  "Євген",     "Афанасьєв",    "Кафедра економіки");
        Teacher afanasev2= new Teacher(6L,  "Ігор",      "Афанасьєв",    "Кафедра економіки");
        Teacher tykhanskiy=new Teacher(7L,  "Михайло",   "Тиханський",   "Кафедра автоматизації");
        Teacher savytskiy= new Teacher(8L,  "Олександр", "Савицький",    "Кафедра автоматизації");
        Teacher dolhikh  = new Teacher(9L,  "Олександр", "Долгіх",       "Кафедра гірництва");
        Teacher dolhikh2 = new Teacher(10L, "Любов",     "Долгіх",       "Кафедра гірництва");
        Teacher kozariz  = new Teacher(11L, "Володимир", "Козаріз",      "Кафедра гірництва");
        Teacher oliynyk  = new Teacher(12L, "Тетяна",    "Олійник",      "Кафедра гірництва");
        Teacher sinchuk  = new Teacher(13L, "Олег",      "Сінчук",       "Кафедра електроенергетики");
        Teacher pyshchykova=new Teacher(14L,"Олена",     "Пищикова",     "Кафедра цивільної безпеки");
        Teacher nesterenko=new Teacher(15L, "Оксана",    "Нестеренко",   "Кафедра цивільної безпеки");
        Teacher bondar   = new Teacher(16L, "Ірина",     "Бондар",       "Кафедра іноземних мов");
        Teacher stupnik  = new Teacher(17L, "Микола",    "Ступнік",      "Кафедра гірництва");

        // ── Дисципліни ──
        Subject inozMova       = new Subject(1L,  "Іноземна мова");
        Subject filosofiya     = new Subject(2L,  "Філософія науки та інновації");
        Subject orhanizatsiya  = new Subject(3L,  "Організація наукових досліджень");
        Subject teorEkon       = new Subject(4L,  "Теорія економічних систем");
        Subject investInov     = new Subject(5L,  "Інвестиційно-інноваційний розвиток");
        Subject ekonomMatem    = new Subject(6L,  "Економіко-математичне моделювання");
        Subject suchMetody     = new Subject(7L,  "Сучасні методи інтелектуальних систем");
        Subject keruvannya     = new Subject(8L,  "Керування мехатронними системами");
        Subject geoinform      = new Subject(9L,  "Геоінформаційні системи");
        Subject mekhanika      = new Subject(10L, "Механіка підземних споруд");
        Subject elektroSys     = new Subject(11L, "Системи виробництва електроенергії");
        Subject otsinka        = new Subject(12L, "Оцінка ризику робітничих професій");

        // ── Групи ──
        Studentgroup akitr241a = new Studentgroup(1L,  "АКІТР-24-1а");
        Studentgroup bi241a    = new Studentgroup(2L,  "БІ-24-1а");
        Studentgroup gr241a    = new Studentgroup(3L,  "ГР-24-1а");
        Studentgroup eem241a   = new Studentgroup(4L,  "ЕЕМ-24-1а");
        Studentgroup ep241a    = new Studentgroup(5L,  "ЕП-24-1а");
        Studentgroup mn241a    = new Studentgroup(6L,  "МН-24-1а");
        Studentgroup cb241a    = new Studentgroup(7L,  "ЦБ-24-1а");
        Studentgroup akit231a  = new Studentgroup(8L,  "АКІТ-23-1а");
        Studentgroup gr231a    = new Studentgroup(9L,  "ГР-23-1а");
        Studentgroup eem231a   = new Studentgroup(10L, "ЕЕМ-23-1а");
        Studentgroup ep231a    = new Studentgroup(11L, "ЕП-23-1а");
        Studentgroup mn231a    = new Studentgroup(12L, "МН-23-1а");
        Studentgroup cb231a    = new Studentgroup(13L, "ЦБ-23-1а");

        // ── Записи (1 тиждень, дати починаючи з понеділка 2025-02-03) ──
        List<Workentry> list = new ArrayList<>();
        long id = 1;

        // Голівер — Іноземна мова
        list.add(new Workentry(id++, goliver, inozMova, akitr241a, LocalDate.of(2025,2,3),  2.0, Worktype.PRACTICAL,  "1 тиждень, пон, 4 пара"));
        list.add(new Workentry(id++, goliver, inozMova, eem241a,   LocalDate.of(2025,2,3),  2.0, Worktype.PRACTICAL,  "1 тиждень, пон, 4 пара"));
        list.add(new Workentry(id++, goliver, inozMova, akitr241a, LocalDate.of(2025,2,4),  2.0, Worktype.PRACTICAL,  "1 тиждень, вів, 4 пара"));
        list.add(new Workentry(id++, goliver, inozMova, akit231a,  LocalDate.of(2025,2,4),  2.0, Worktype.PRACTICAL,  "1 тиждень, вів, 4 пара"));
        list.add(new Workentry(id++, goliver, inozMova, gr231a,    LocalDate.of(2025,2,4),  2.0, Worktype.PRACTICAL,  "1 тиждень, вів, 4 пара"));
        list.add(new Workentry(id++, goliver, inozMova, eem231a,   LocalDate.of(2025,2,4),  2.0, Worktype.PRACTICAL,  "1 тиждень, вів, 4 пара"));
        list.add(new Workentry(id++, goliver, inozMova, akit231a,  LocalDate.of(2025,2,6),  2.0, Worktype.PRACTICAL,  "1 тиждень, чет, 2 пара"));
        list.add(new Workentry(id++, goliver, inozMova, gr231a,    LocalDate.of(2025,2,6),  2.0, Worktype.PRACTICAL,  "1 тиждень, чет, 2 пара"));

        // Цимбал — Філософія
        list.add(new Workentry(id++, tsymbal, filosofiya, akitr241a, LocalDate.of(2025,2,3), 2.0, Worktype.LECTURE,   "1 тиждень, пон, 5 пара"));
        list.add(new Workentry(id++, tsymbal, filosofiya, bi241a,    LocalDate.of(2025,2,3), 2.0, Worktype.LECTURE,   "1 тиждень, пон, 5 пара"));
        list.add(new Workentry(id++, tsymbal, filosofiya, gr241a,    LocalDate.of(2025,2,3), 2.0, Worktype.LECTURE,   "1 тиждень, пон, 5 пара"));
        list.add(new Workentry(id++, tsymbal, filosofiya, eem241a,   LocalDate.of(2025,2,3), 2.0, Worktype.LECTURE,   "1 тиждень, пон, 5 пара"));
        list.add(new Workentry(id++, tsymbal, filosofiya, ep241a,    LocalDate.of(2025,2,3), 2.0, Worktype.LECTURE,   "1 тиждень, пон, 5 пара"));
        list.add(new Workentry(id++, tsymbal, filosofiya, mn241a,    LocalDate.of(2025,2,3), 2.0, Worktype.LECTURE,   "1 тиждень, пон, 5 пара"));
        list.add(new Workentry(id++, tsymbal, filosofiya, cb241a,    LocalDate.of(2025,2,3), 2.0, Worktype.LECTURE,   "1 тиждень, пон, 5 пара"));
        list.add(new Workentry(id++, tsymbal, filosofiya, bi241a,    LocalDate.of(2025,2,3), 2.0, Worktype.PRACTICAL, "1 тиждень, пон, 6 пара"));

        // Бровко — Організація досліджень
        list.add(new Workentry(id++, brovko, orhanizatsiya, akitr241a, LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 4 пара"));
        list.add(new Workentry(id++, brovko, orhanizatsiya, bi241a,    LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 4 пара"));
        list.add(new Workentry(id++, brovko, orhanizatsiya, gr241a,    LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 4 пара"));
        list.add(new Workentry(id++, brovko, orhanizatsiya, eem241a,   LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 4 пара"));
        list.add(new Workentry(id++, brovko, orhanizatsiya, ep241a,    LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 4 пара"));
        list.add(new Workentry(id++, brovko, orhanizatsiya, mn241a,    LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 4 пара"));

        // Тронь — Практичні заняття
        list.add(new Workentry(id++, tron, orhanizatsiya, bi241a,  LocalDate.of(2025,2,5), 2.0, Worktype.PRACTICAL, "1 тиждень, сер, 5 пара"));
        list.add(new Workentry(id++, tron, orhanizatsiya, gr241a,  LocalDate.of(2025,2,5), 2.0, Worktype.PRACTICAL, "1 тиждень, сер, 5 пара"));
        list.add(new Workentry(id++, tron, orhanizatsiya, eem241a, LocalDate.of(2025,2,5), 2.0, Worktype.PRACTICAL, "1 тиждень, сер, 5 пара"));
        list.add(new Workentry(id++, tron, orhanizatsiya, ep241a,  LocalDate.of(2025,2,6), 2.0, Worktype.PRACTICAL, "1 тиждень, чет, 4 пара"));
        list.add(new Workentry(id++, tron, orhanizatsiya, mn241a,  LocalDate.of(2025,2,6), 2.0, Worktype.PRACTICAL, "1 тиждень, чет, 4 пара"));

        // Афанасьєв Є. — Економіка
        list.add(new Workentry(id++, afanasev, teorEkon, ep241a,   LocalDate.of(2025,2,4), 2.0, Worktype.LECTURE,   "1 тиждень, вів, 5 пара"));
        list.add(new Workentry(id++, afanasev, teorEkon, mn241a,   LocalDate.of(2025,2,4), 2.0, Worktype.LECTURE,   "1 тиждень, вів, 5 пара"));
        list.add(new Workentry(id++, afanasev, investInov, ep231a, LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 5 пара"));
        list.add(new Workentry(id++, afanasev, investInov, mn231a, LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 5 пара"));
        list.add(new Workentry(id++, afanasev, ekonomMatem, mn231a,LocalDate.of(2025,2,3), 2.0, Worktype.LECTURE,   "1 тиждень, пон, 5 пара"));

        // Тиханський — Автоматизація
        list.add(new Workentry(id++, tykhanskiy, suchMetody, akit231a, LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 5 пара"));
        list.add(new Workentry(id++, tykhanskiy, suchMetody, akit231a, LocalDate.of(2025,2,5), 2.0, Worktype.PRACTICAL, "1 тиждень, сер, 6 пара"));

        // Савицький — Мехатроніка
        list.add(new Workentry(id++, savytskiy, keruvannya, akit231a, LocalDate.of(2025,2,6), 2.0, Worktype.LECTURE,   "1 тиждень, чет, 5 пара"));
        list.add(new Workentry(id++, savytskiy, keruvannya, akit231a, LocalDate.of(2025,2,6), 2.0, Worktype.PRACTICAL, "1 тиждень, чет, 6 пара"));
        list.add(new Workentry(id++, sinchuk,   keruvannya, eem231a,  LocalDate.of(2025,2,6), 2.0, Worktype.LECTURE,   "1 тиждень, чет, 4 пара"));

        // Долгіх — Гірництво
        list.add(new Workentry(id++, dolhikh,  geoinform, gr231a, LocalDate.of(2025,2,6), 2.0, Worktype.LECTURE,   "1 тиждень, чет, 5 пара"));
        list.add(new Workentry(id++, dolhikh,  geoinform, gr231a, LocalDate.of(2025,2,6), 2.0, Worktype.PRACTICAL, "1 тиждень, чет, 6 пара"));
        list.add(new Workentry(id++, dolhikh2, geoinform, gr231a, LocalDate.of(2025,2,7), 2.0, Worktype.PRACTICAL, "1 тиждень, пят, 5 пара"));
        list.add(new Workentry(id++, kozariz,  mekhanika, gr231a, LocalDate.of(2025,2,5), 2.0, Worktype.LECTURE,   "1 тиждень, сер, 5 пара"));
        list.add(new Workentry(id++, stupnik,  mekhanika, gr241a, LocalDate.of(2025,2,4), 2.0, Worktype.LECTURE,   "1 тиждень, вів, 4 пара"));

        // Бондар — Іноземна мова
        list.add(new Workentry(id++, bondar, inozMova, gr241a,  LocalDate.of(2025,2,6), 2.0, Worktype.PRACTICAL, "1 тиждень, чет, 5 пара"));
        list.add(new Workentry(id++, bondar, inozMova, ep241a,  LocalDate.of(2025,2,6), 2.0, Worktype.PRACTICAL, "1 тиждень, чет, 5 пара"));
        list.add(new Workentry(id++, bondar, inozMova, mn241a,  LocalDate.of(2025,2,6), 2.0, Worktype.PRACTICAL, "1 тиждень, чет, 5 пара"));

        // Пищикова, Нестеренко — Цивільна безпека
        list.add(new Workentry(id++, pyshchykova, otsinka, cb231a, LocalDate.of(2025,2,6), 2.0, Worktype.LECTURE, "1 тиждень, чет, 4 пара"));
        list.add(new Workentry(id++, nesterenko,  otsinka, cb231a, LocalDate.of(2025,2,6), 2.0, Worktype.LECTURE, "1 тиждень, чет, 4 пара"));

        return list;
    }
}