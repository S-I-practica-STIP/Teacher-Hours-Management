package com.example.kpoopuishcherbakivan;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class HelloController {

    // ── @FXML поля — прив'язка до елементів main-view.fxml ──
    @FXML private TableColumn<Workentry, String> colGroup;
    @FXML private TableColumn<Workentry, Double> colHours;
    @FXML private TableColumn<Workentry, String> colSubject;
    @FXML private TableColumn<Workentry, String> colTeacher;
    @FXML private TableColumn<Workentry, String> colType;
    @FXML private Button showAllBtn;
    @FXML private Button backBtn;
    @FXML private Button editBtn;    // Кнопка редагування
    @FXML private Button saveBtn;    // Кнопка збереження у TXT
    @FXML private Button loadBtn;    // Кнопка завантаження з TXT
    @FXML private Button reportBtn;  // Кнопка генерації звіту
    @FXML private ComboBox<String> teacherFilter;
    @FXML private Label totalLabel;
    @FXML private TableView<Workentry> workTable;

    // Головний список записів (ObservableList — автооновлення таблиці)
    private ObservableList<Workentry> allEntries;

    // ── initialize() — виконується автоматично при завантаженні FXML ──
    @FXML
    void initialize() {
        // Прив'язка колонок до полів об'єктів Workentry
        colTeacher.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getTeacher().getFullName()));
        colSubject.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getSubject().getName()));
        colGroup.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getGroup().getCode()));
        colHours.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleDoubleProperty(
                        cell.getValue().getHours()).asObject());
        colType.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getType().getDisplayName()));

        // Завантаження початкових даних з DataStore
        allEntries = FXCollections.observableArrayList(
                DataStore.getEntries());
        workTable.setItems(allEntries);

        // Динамічне формування списку викладачів для фільтра
        refreshTeacherFilter();
        updateTotal(allEntries);
    }

    // ── Допоміжний метод: оновлює список викладачів у фільтрі ──
    private void refreshTeacherFilter() {
        String current = teacherFilter.getValue();
        ObservableList<String> names =
                FXCollections.observableArrayList();
        names.add("Всі");
        for (Workentry e : allEntries) {
            String name = e.getTeacher().getFullName();
            if (!names.contains(name)) names.add(name);
        }
        teacherFilter.setItems(names);
        teacherFilter.setValue(
                names.contains(current) ? current : "Всі");
    }

    // ── Кнопка «Назад» — повернення до вікна логіну ──
    @FXML
    void onBack() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("login-view.fxml"));
            Stage stage = (Stage) backBtn.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 400, 300));
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── Кнопка «Показати все» — скидає фільтр ──
    @FXML
    void onShowAll() {
        workTable.setItems(allEntries);
        teacherFilter.setValue("Всі");
        updateTotal(allEntries);
    }

    // ── Кнопка «+» — відкриває форму додавання нового запису ──
    @FXML
    void onAdd() {
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("add-view.fxml"));
            Stage addStage = new Stage();
            addStage.setTitle("Додати запис");
            addStage.setScene(new Scene(loader.load(), 350, 450));
            AddController ctrl = loader.getController();
            // Callback: отримуємо новий запис після збереження
            ctrl.setOnSaveCallback(entry -> {
                entry.setId((long)(allEntries.size() + 1));
                allEntries.add(entry);
                refreshTeacherFilter();
                updateTotal(allEntries);
            });
            addStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── Кнопка «✏️» — відкриває форму редагування виділеного запису ──
    @FXML
    void onEdit() {
        Workentry selected =
                workTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "Оберіть запис для редагування!");
            return;
        }
        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("add-view.fxml"));
            Stage editStage = new Stage();
            editStage.setTitle("Редагувати запис");
            editStage.setScene(new Scene(loader.load(), 350, 450));
            AddController ctrl = loader.getController();
            // Заповнюємо форму даними існуючого запису
            ctrl.fillForEdit(selected);
            // Callback: замінюємо старий запис відредагованим
            ctrl.setOnSaveCallback(entry -> {
                entry.setId(selected.getId());
                int index = allEntries.indexOf(selected);
                if (index >= 0) allEntries.set(index, entry);
                updateTotal(allEntries);
            });
            editStage.show();
        } catch (Exception e) { e.printStackTrace(); }
    }

    // ── Кнопка «-» — видалення з підтвердженням ──
    @FXML
    void onDelete() {
        Workentry selected =
                workTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert(Alert.AlertType.WARNING,
                    "Оберіть запис для видалення!");
            return;
        }
        // Діалог підтвердження з деталями запису
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Підтвердження видалення");
        confirm.setHeaderText(null);
        confirm.setContentText(
                "Видалити запис?\n" +
                        "Викладач: " + selected.getTeacher().getFullName() +
                        "\nПредмет: " + selected.getSubject().getName() +
                        "\nДата: "   + selected.getDate());
        java.util.Optional<ButtonType> result = confirm.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            allEntries.remove(selected);
            refreshTeacherFilter();
            updateTotal(allEntries);
        }
    }

    // ── Кнопка «💾 Зберегти» — збереження у TXT файл ──
    @FXML
    void onSave() {
        boolean ok = FileManager.save(allEntries);
        if (ok) {
            showAlert(Alert.AlertType.INFORMATION,
                    "Дані збережено у файл: " +
                            FileManager.getFilePath());
        } else {
            showAlert(Alert.AlertType.ERROR,
                    "Помилка збереження файлу!");
        }
    }

    // ── Кнопка «📂 Завантажити» — завантаження з TXT файлу ──
    @FXML
    void onLoad() {
        java.util.List<Workentry> loaded = FileManager.load();
        if (loaded.isEmpty()) {
            showAlert(Alert.AlertType.WARNING,
                    "Файл порожній або не знайдено: " +
                            FileManager.getFilePath());
            return;
        }
        // Замінюємо поточні дані завантаженими
        allEntries.setAll(loaded);
        refreshTeacherFilter();
        updateTotal(allEntries);
        showAlert(Alert.AlertType.INFORMATION,
                "Завантажено " + loaded.size() + " записів з файлу.");
    }

    // ── Кнопка «📄 Звіт» — генерація текстового звіту ──
    @FXML
    void onReport() {
        if (allEntries.isEmpty()) {
            showAlert(Alert.AlertType.WARNING,
                    "Список записів порожній — нічого генерувати!");
            return;
        }
        boolean ok = ReportGenerator.generate(allEntries);
        if (ok) {
            showAlert(Alert.AlertType.INFORMATION,
                    "Звіт збережено у файл: report.txt");
        } else {
            showAlert(Alert.AlertType.ERROR,
                    "Помилка генерації звіту!");
        }
    }

    // ── Фільтрація таблиці за обраним викладачем ──
    @FXML
    void onFilterChanged() {
        String selected = teacherFilter.getValue();
        if (selected == null || selected.equals("Всі")) {
            workTable.setItems(allEntries);
            updateTotal(allEntries);
        } else {
            ObservableList<Workentry> filtered =
                    FXCollections.observableArrayList();
            for (Workentry e : allEntries)
                if (e.getTeacher().getFullName().equals(selected))
                    filtered.add(e);
            workTable.setItems(filtered);
            updateTotal(filtered);
        }
    }

    // ── Підрахунок та відображення загальних годин ──
    private void updateTotal(ObservableList<Workentry> list) {
        double total = 0;
        for (Workentry e : list) total += e.getHours();
        totalLabel.setText("Всього годин: " + total);
    }

    // ── Допоміжний метод для показу діалогових вікон ──
    private void showAlert(Alert.AlertType type, String message) {
        Alert alert = new Alert(type);
        alert.setTitle("Система обліку навантаження");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
