package com.example.kpoopuishcherbakivan;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class ReportGenerator {

    private static final String SEPARATOR =
            "================================================";
    private static final String THIN =
            "------------------------------------------------";

    public static boolean generate(List<Workentry> entries) {
        String fileName = "report.txt";

        try (PrintWriter writer =
                     new PrintWriter(new BufferedWriter(
                             new FileWriter(fileName)))) {

            writer.println(SEPARATOR);
            writer.println("  ЗВІТ ПРО НАВАНТАЖЕННЯ ВИКЛАДАЧІВ");
            writer.println("  Дата формування: " +
                    LocalDateTime.now().format(
                            DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")));
            writer.println(SEPARATOR);
            writer.println();

            Map<String, List<Workentry>> byTeacher =
                    new LinkedHashMap<>();
            for (Workentry e : entries) {
                String name = e.getTeacher().getFullName();
                byTeacher.computeIfAbsent(name,
                        k -> new ArrayList<>()).add(e);
            }

            double grandTotal = 0;

            for (Map.Entry<String, List<Workentry>> entry :
                    byTeacher.entrySet()) {

                writer.println("Викладач: " + entry.getKey());
                writer.println("Кафедра:  " +
                        entry.getValue().get(0)
                                .getTeacher().getDepartment());
                writer.println(THIN);

                double total = 0;
                for (Workentry e : entry.getValue()) {
                    writer.printf("  %-12s | %-15s | %-8s | %4.1f год | %s%n",
                            e.getDate().toString(),
                            e.getSubject().getName(),
                            e.getGroup().getCode(),
                            e.getHours(),
                            e.getType().toString());
                    total += e.getHours();
                }

                writer.println(THIN);
                writer.printf("  Всього годин: %.1f%n", total);
                writer.println();
                grandTotal += total;
            }

            writer.println(SEPARATOR);
            writer.printf("  ЗАГАЛЬНЕ НАВАНТАЖЕННЯ: %.1f год%n",
                    grandTotal);
            writer.printf("  Кількість записів:     %d%n",
                    entries.size());
            writer.println(SEPARATOR);

            return true;

        } catch (IOException e) {
            System.err.println(
                    "Помилка генерації звіту: " + e.getMessage());
            return false;
        }
    }
}
