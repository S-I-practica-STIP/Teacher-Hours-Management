package com.example.kpoopuishcherbakivan;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.time.LocalDate;

public class AddController {

    @FXML private ComboBox<String> teacherBox;
    @FXML private ComboBox<String> subjectBox;
    @FXML private ComboBox<String> groupBox;
    @FXML private DatePicker datePicker;
    @FXML private TextField hoursField;
    @FXML private ComboBox<String> typeBox;
    @FXML private TextField descField;
    @FXML private Button saveBtn;
    @FXML private Button backBtn;

    // Callback для передачі збереженого запису назад у HelloController
    private java.util.function.Consumer<Workentry> onSaveCallback;

    public void setOnSaveCallback(
            java.util.function.Consumer<Workentry> callback) {
        this.onSaveCallback = callback;
    }

    /**
     * Заповнює всі поля форми даними існуючого запису.
     * Викликається при редагуванні з HelloController.onEdit()
     */
    public void fillForEdit(Workentry entry) {
        teacherBox.setValue(entry.getTeacher().getFullName());
        subjectBox.setValue(entry.getSubject().getName());
        groupBox.setValue(entry.getGroup().getCode());
        typeBox.setValue(entry.getType().toString());
        datePicker.setValue(entry.getDate());
        hoursField.setText(String.valueOf(entry.getHours()));
        if (entry.getDescription() != null)
            descField.setText(entry.getDescription());
    }

    @FXML
    void initialize() {
        teacherBox.setItems(FXCollections.observableArrayList(
                "Олена Петренко", "Микола Коваль"));
        subjectBox.setItems(FXCollections.observableArrayList(
                "ООП", "Бази даних"));
        groupBox.setItems(FXCollections.observableArrayList(
                "ІПЗ-23", "ІПЗ-22"));
        typeBox.setItems(FXCollections.observableArrayList(
                "LECTURE", "PRACTICAL", "LAB",
                "CONSULTATION", "METHODICAL", "EXAM"));
        teacherBox.setValue("Олена Петренко");
        subjectBox.setValue("ООП");
        groupBox.setValue("ІПЗ-23");
        typeBox.setValue("LECTURE");
        datePicker.setValue(LocalDate.now());
    }

    @FXML
    void onSave() {
        try {
            double hours = Double.parseDouble(hoursField.getText());
            Teacher teacher = findTeacher(teacherBox.getValue());
            Subject subject = findSubject(subjectBox.getValue());
            Studentgroup group = findGroup(groupBox.getValue());
            Worktype type = Worktype.valueOf(typeBox.getValue());
            Workentry entry = new Workentry(null, teacher, subject,
                    group, datePicker.getValue(),
                    hours, type, descField.getText());
            if (onSaveCallback != null) onSaveCallback.accept(entry);
            onBack();
        } catch (NumberFormatException e) {
            hoursField.setStyle("-fx-border-color: red;");
        }
    }

    @FXML
    void onBack() {
        ((Stage) backBtn.getScene().getWindow()).close();
    }

    private Teacher findTeacher(String name) {
        for (Workentry e : DataStore.getEntries())
            if (e.getTeacher().getFullName().equals(name))
                return e.getTeacher();
        return new Teacher(99L,
                name.split(" ")[0], name.split(" ")[1], "");
    }

    private Subject findSubject(String name) {
        for (Workentry e : DataStore.getEntries())
            if (e.getSubject().getName().equals(name))
                return e.getSubject();
        return new Subject(99L, name);
    }

    private Studentgroup findGroup(String code) {
        for (Workentry e : DataStore.getEntries())
            if (e.getGroup().getCode().equals(code))
                return e.getGroup();
        return new Studentgroup(99L, code);
    }
}
