package com.example.kpoopuishcherbakivan;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class StatsController {

    @FXML private Button backBtn;
    @FXML private TableView<String[]> statsTable;
    @FXML private TableColumn<String[], String> colTeacher;
    @FXML private TableColumn<String[], String> colTotal;
    @FXML private TableColumn<String[], String> colPercent;
    @FXML private Label summaryLabel;

    private static final double MAX_HOURS = 20.0; // норма годин

    @FXML
    void initialize() {
        colTeacher.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(cell.getValue()[0]));
        colTotal.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(cell.getValue()[1]));
        colPercent.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(cell.getValue()[2]));

        ObservableList<Workentry> all =
                FXCollections.observableArrayList(DataStore.getEntries());

        // Рахуємо години по кожному викладачу
        java.util.Map<String, Double> map = new java.util.LinkedHashMap<>();
        for (Workentry e : all) {
            String name = e.getTeacher().getFullName();
            map.put(name, map.getOrDefault(name, 0.0) + e.getHours());
        }

        ObservableList<String[]> rows = FXCollections.observableArrayList();
        double grandTotal = 0;
        for (java.util.Map.Entry<String, Double> entry : map.entrySet()) {
            double hours = entry.getValue();
            double percent = Math.min(100, (hours / MAX_HOURS) * 100);
            String status = percent >= 90 ? "! " + (int)percent + "%" :
                    percent >= 60 ? "🟡 " + (int)percent + "%" :
                    "🟢 " + (int)percent + "%";
            rows.add(new String[]{entry.getKey(), hours + " год", status});
            grandTotal += hours;
        }
        statsTable.setItems(rows);
        summaryLabel.setText("Загальне навантаження: " + grandTotal + " год");
    }

    @FXML
    void onBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login-view.fxml"));
            Stage stage = (Stage) backBtn.getScene().getWindow();
            stage.setScene(new Scene(loader.load(), 400, 300));
        } catch (Exception e) { e.printStackTrace(); }
    }
}