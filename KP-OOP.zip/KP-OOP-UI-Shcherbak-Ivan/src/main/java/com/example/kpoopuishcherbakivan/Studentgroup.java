package com.example.kpoopuishcherbakivan;

// Класс "Академічна група"
public class Studentgroup {

    private Long id;
    private String code;

    public Studentgroup(Long id, String code) {
        this.id = id;
        this.code = code;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    @Override
    public String toString() {
        return "StudentGroup{id=" + id + ", code='" + code + "'}";
    }
}