package com.example.kpoopuishcherbakivan;

// Класс "Вчитель"
public class Teacher {

    private Long id;
    private String firstName;   // Ім'я
    private String lastName;    // Прізвище
    private String department;  // Кафедра

    public Teacher(Long id, String firstName, String lastName, String department) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    @Override
    public String toString() {
        return "Teacher{id=" + id + ", name='" + getFullName() + "', dept='" + department + "'}";
    }
}