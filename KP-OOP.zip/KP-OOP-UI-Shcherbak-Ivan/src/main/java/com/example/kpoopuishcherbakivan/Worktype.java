package com.example.kpoopuishcherbakivan;

// Фіксований список "Тип работи"
public enum Worktype {
    LECTURE,
    PRACTICAL,
    LAB,
    CONSULTATION,
    METHODICAL,
    EXAM;

    public String getDisplayName() {
        switch (this) {
            case LECTURE:      return "Лекція";
            case PRACTICAL:    return "Практика";
            case LAB:          return "Лабораторна";
            case CONSULTATION: return "Консультація";
            case METHODICAL:   return "Методична";
            case EXAM:         return "Іспит";
            default:           return this.toString();
        }
    }
}